package com.example.escola;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class perfilAluno extends AppCompatActivity {

    private int alunoId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_perfil_aluno);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        carregarDados();

        Button btnCadastro = findViewById(R.id.btn_cadastro);
        btnCadastro.setOnClickListener(v -> {
            Intent intent = new Intent(perfilAluno.this, CadastrarAluno.class);
            startActivity(intent);
        });


        Button btneditar = findViewById(R.id.btn_editar);
        btneditar.setOnClickListener(v -> {
            Intent intent = new Intent(perfilAluno.this, editarAluno.class);
            intent.putExtra("id", alunoId);
            startActivity(intent);
        });

        Button btnexcluir = findViewById(R.id.btn_excluir);
        btnexcluir.setOnClickListener(v -> {
            excluirDados();
            Intent intent = new Intent(perfilAluno.this, MainActivity.class);
            startActivity(intent);
        });
    }

    private void carregarDados() {
        TextView nome = findViewById(R.id.text_nome);
        TextView cpf = findViewById(R.id.text_CPF);
        TextView cep = findViewById(R.id.text_cep);
        TextView dataNasc = findViewById(R.id.text_dataNasc);
        TextView email = findViewById(R.id.text_email);
        TextView nomeResp = findViewById(R.id.text_nomeResp);
        TextView tel = findViewById(R.id.text_tel);

        alunoId = getIntent().getIntExtra("id", -1);

        Escola_DB dbHelper = new Escola_DB(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT nome, cpf, cep, data_nasc, email, nome_resp, celular FROM aluno WHERE id = ?", new String[]{String.valueOf(alunoId)});

        if (cursor.moveToFirst()) {
            nome.setText(cursor.getString(0));
            cpf.setText(cursor.getString(1));
            cep.setText(cursor.getString(2));
            dataNasc.setText(cursor.getString(3));
            email.setText(cursor.getString(4));
            nomeResp.setText(cursor.getString(5));
            tel.setText(cursor.getString(6));
        } else {
            nome.setText("Aluno não encontrado");
        }

        cursor.close();
        db.close();
    }

    private void excluirDados() {
        Escola_DB dbHelper = new Escola_DB(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        db.delete("aluno", "id = ?", new String[]{String.valueOf(alunoId)});
        db.close();
    }

}
