package com.example.escola;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Cadastrar_Turmas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastrar_turmas);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        RecyclerView recyclerProf = findViewById(R.id.recycler_prof_Turma);
        recyclerProf.setLayoutManager(new LinearLayoutManager(this));

        RecyclerView recyclerAluno = findViewById(R.id.recycler_aluno_turma);
        recyclerAluno.setLayoutManager(new LinearLayoutManager(this));

        Escola_DB db = new Escola_DB(this);
        List<Professor> listaProf = db.listarProfessores();
        ProfessorTurma adapterProfessorTurma = new ProfessorTurma(this, listaProf);
        recyclerProf.setAdapter(adapterProfessorTurma);

        List<Aluno> listaAluno = db.listarAlunos();
        AlunoTurma adapterAluno = new AlunoTurma(this, listaAluno);
        recyclerAluno.setAdapter(adapterAluno);



        Button btnsalvar = findViewById(R.id.btn_editar);

        btnsalvar.setOnClickListener(v -> {
            EditText nomeTurma = findViewById(R.id.input_nomeTurma);
            RadioGroup turnoTurma = findViewById(R.id.radioGroupTurno);

            Escola_DB dbHelper = new Escola_DB(this);

            String nome = edtNome.getText().toString();

            long result = dbHelper.inserirAluno(nome);

            if (result != -1) {
                Intent intent = new Intent(Cadastrar_Turmas.this, MainActivity.class);
                startActivity(intent);

            } else {
                Toast.makeText(this, "Erro ao salvar. CPF pode estar duplicado!", Toast.LENGTH_SHORT).show();
            }
        });

    }

}