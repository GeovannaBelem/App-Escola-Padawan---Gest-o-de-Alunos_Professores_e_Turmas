package com.example.escola;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ProfessorTurma extends RecyclerView.Adapter<ProfessorTurma.ProfessorViewHolder>{
    private List<Professor> listaProfessores;
    private Context context;

    public ProfessorTurma(Context context, List<Professor> listaProfessores) {
        this.context = context;
        this.listaProfessores = listaProfessores;
    }

    @NonNull
    @Override
    public ProfessorTurma.ProfessorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.professor_turma, parent, false);
        return new ProfessorTurma.ProfessorViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProfessorTurma.ProfessorViewHolder holder, int position) {
        Professor prof = listaProfessores.get(position);
        holder.nome.setText(prof.getNome());
    }

    @Override
    public int getItemCount() {
        return listaProfessores.size();
    }

    public static class ProfessorViewHolder extends RecyclerView.ViewHolder {
        TextView nome;

        public ProfessorViewHolder(@NonNull View itemView) {
            super(itemView);
            nome = itemView.findViewById(R.id.nomeprof);
        }
    }
}
